================================================================================
                         DISCLAIMER & USAGE GUIDE
================================================================================

[!] DISCLAIMER
This rig is provided "as is" and is NOT a final or stable release.
The creator assumes no responsibility or liability for any errors, broken
files, project issues, or damage resulting from the use of this file.

--------------------------------------------------------------------------------
REQUIREMENTS & TOOLS
--------------------------------------------------------------------------------
To export/import facial animations using this rig, you will need:

- Blender Face Animation Exporter (Add-on):
  https://github.com/mr-xen0/rbx-faceanim-exporter

- Roblox Face Animation Importer (Roblox Plugin):
  https://create.roblox.com/store/asset/81143924403575/Face-Animation-Importer

--------------------------------------------------------------------------------
CREDITS & ASSET ATTRIBUTION
--------------------------------------------------------------------------------
All facial texture images included and used in this rig are part of
AltiWyre's Face Pack, created by @AltiWyre.

The creator of this rig has no affiliation with the creation of these assets
and claims no copyright over them.

- Original Face Pack:
  https://create.roblox.com/store/asset/6557969904/AltiWyres-Face-Pack

--------------------------------------------------------------------------------
LICENSE & TERMS OF USE
--------------------------------------------------------------------------------
- This rig is created NOT FOR SALE and will always remain
  completely free.

- Do not use this rig or assets for commercial purposes.

--------------------------------------------------------------------------------
FEEDBACK & BUG REPORTING
--------------------------------------------------------------------------------
If you found a bug or have suggestions for improvements, you can report them
on the forum page.

--------------------------------------------------------------------------------
AUTHOR & CONTACT
--------------------------------------------------------------------------------
To find my other projects or contact info, visit my website:
  https://mrxeno.com
